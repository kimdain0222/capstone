// static/calendar.js


function initCalendar(bodyId) {
  const calendarBody   = document.getElementById(bodyId);
  const monthYearElem  = document.getElementById("month-year");
  const prevBtn        = document.getElementById("prev");
  const nextBtn        = document.getElementById("next");

  // 오늘 날짜 기반으로 초기 월/년 설정
  let today        = new Date();
  let currentMonth = today.getMonth(); // 0:1월, 11:12월
  let currentYear  = today.getFullYear();

  // 달력 렌더링 함수
  function renderCalendar(month, year) {
    // 이전 내용 초기화
    calendarBody.innerHTML = "";

    // 해당 달의 첫째 날 요일(0:일요일 ~ 6:토요일), 총 일수
    const firstDay   = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // 상단 제목 세팅
    monthYearElem.textContent = `${year}년 ${month + 1}월`;

    let date = 1;
    // 최대 6주(행) 반복
    for (let week = 0; week < 6; week++) {
      const row = document.createElement("tr");

      // 7일(열) 반복
      for (let day = 0; day < 7; day++) {
        const cell = document.createElement("td");

        // 첫째 주의 빈 칸 처리
        if (week === 0 && day < firstDay) {
          cell.textContent = "";
        }
        // 날짜가 남아있으면 채우고, 아니면 빈 칸
        else if (date > daysInMonth) {
          cell.textContent = "";
        } else {
          cell.textContent = date;
          date++;
        }

        row.appendChild(cell);
      }

      calendarBody.appendChild(row);
    }
  }

  // Prev 버튼 클릭
  prevBtn.addEventListener("click", () => {
    currentMonth = currentMonth === 0 ? 11 : currentMonth - 1;
    currentYear  = currentMonth === 11 ? currentYear - 1 : currentYear;
    renderCalendar(currentMonth, currentYear);
  });

  // Next 버튼 클릭
  nextBtn.addEventListener("click", () => {
    currentMonth = currentMonth === 11 ? 0 : currentMonth + 1;
    currentYear  = currentMonth === 0 ? currentYear + 1 : currentYear;
    renderCalendar(currentMonth, currentYear);
  });

  // 최초 렌더링
  renderCalendar(currentMonth, currentYear);

  calendarBody.addEventListener('click', async e => {
    const td = e.target.closest('td')
    if (!td || !td.textContent.trim()) return

    const user = JSON.parse(localStorage.getItem("smartday_user") || "{}");
    if (!user || !user.id) {
      alert("일정을 보려면 로그인 이후에 이용해주세요.");
      return;
    }

    const [year, monthText] = monthYearElem.textContent.match(/\d+/g)
    const day   = td.textContent.trim().padStart(2, '0')
    const month = monthText.padStart(2, '0')

    const dateInt = Number(`${year}${month}${day}`)  // YYYYMMDD 정수
    await loadSchedules(dateInt)

    document.getElementById('schedule-container').style.display = 'block'
  })
}

document.addEventListener('DOMContentLoaded', () => {
  initCalendar('calendar-body')
})