let selectedDate = null
const user = JSON.parse(localStorage.getItem('smartday_user') || '{}')
const userId = user.id

// 시간표·폼 옵션 생성
function initScheduleUI() {
  const tableBody = document.getElementById('schedule-table-body')
  const startSel  = document.getElementById('select-start')
  const endSel    = document.getElementById('select-end')

  for (let h = 0; h < 24; h++) {
    const row = document.createElement('tr')
    row.innerHTML = `<td>${String(h).padStart(2,'0')}:00</td><td></td>`
    row.querySelector('td:nth-child(2)').setAttribute('data-hour', h)
    tableBody.appendChild(row)

    const opt1 = document.createElement('option')
    opt1.value = h
    opt1.textContent = `${String(h).padStart(2,'0')}:00`
    startSel.appendChild(opt1)

    const opt2 = document.createElement('option')
    opt2.value = h
    opt2.textContent = `${String(h).padStart(2,'0')}:00`
    endSel.appendChild(opt2)
  }
  // 24시 옵션 추가 (다음날 00시)
  const opt24 = document.createElement('option')
  opt24.value = 24
  opt24.textContent = '00:00'
  endSel.appendChild(opt24)

  startSel.addEventListener('change', e => {
    const s = parseInt(e.target.value)
    Array.from(endSel.options).forEach(opt => {
      opt.disabled = Number(opt.value) < s
    })
  })
}

async function loadSchedules(dateInt) {
  selectedDate = dateInt
  document.getElementById('schedule-title').textContent = `${dateInt} 일정`

  const res = await fetch(`/calendar_events/${userId}/${dateInt}`)
  const events = await res.json()

  // 시간표 채우기
  document.querySelectorAll('[data-hour]').forEach(td => td.textContent = '')
  events.forEach(ev => {
    const endHour = ev.end
    for (let h = ev.start; h < endHour; h++) {
      const cell = document.querySelector(`[data-hour="${h}"]`)
      if (cell) cell.textContent = ev.title
    }
  })

  // 등록된 일정 리스트
  const ul = document.getElementById('event-list')
  ul.innerHTML = events.length
    ? events.map(ev => {
        return `<li>
                  ${String(ev.start).padStart(2,'0')}:00 — 
                  ${String(ev.end % 24).padStart(2,'0')}:00 : 
                  ${ev.title}
                  <button class="edit-btn" data-id="${ev.id}">수정</button>
                  <button class="del-btn"  data-id="${ev.id}">삭제</button>
                </li>`
      }).join('')
    : '<li>등록된 일정이 없습니다.</li>'
}

// 일정 추가 버튼
document.getElementById('add-schedule-btn').addEventListener('click', () => {
  document.getElementById('form-title').textContent = '일정 추가'
  const form = document.getElementById('form-schedule')
  form.removeAttribute('data-id')
  form.reset()
  document.getElementById('schedule-form').style.display = 'block'
})

// 취소 버튼
document.getElementById('cancel-schedule').addEventListener('click', () => {
  document.getElementById('schedule-form').style.display = 'none'
})

// 폼 제출 (추가/수정)
document.getElementById('form-schedule').addEventListener('submit', async e => {
  e.preventDefault()
  const fm = e.target
  const fd = new FormData(fm)
  const payload = {
    user_id: userId,
    date: selectedDate,
    start: +fd.get('start'),
    end: fd.get('end') ? +fd.get('end') : +fd.get('start'),
    title: fd.get('title'),
    content: fd.get('content')
  }

  const isEdit = fm.dataset.id
  const url    = isEdit
    ? `/calendar_events/${fm.dataset.id}`
    : `/calendar_events`
  const method = isEdit ? 'PUT' : 'POST'

  await fetch(url, {
    method,
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify(payload)
  })

  fm.removeAttribute('data-id')
  fm.reset()
  document.getElementById('schedule-form').style.display = 'none'
  await loadSchedules(selectedDate)
})

// 수정·삭제 버튼 핸들러
document.querySelector('.schedule-actions').addEventListener('click', e => {
  const btn = e.target
  if (btn.matches('.edit-btn')) {
    const id = btn.dataset.id
    const ev = window.events.find(x => x.id == id)
    const fm = document.getElementById('form-schedule')
    fm.dataset.id = id
    document.getElementById('form-title').textContent = '일정 수정'
    fm.title.value = ev.title
    fm.start.value = ev.start
    fm.end.value   = ev.end
    fm.content.value = ev.content || ''
    document.getElementById('schedule-form').style.display = 'block'
  }

  if (btn.matches('.del-btn')) {
    const id = btn.dataset.id
    if (!confirm('정말 삭제하시겠습니까?')) return
    fetch(`/calendar_events/${id}`, { method: 'DELETE' })
      .then(() => loadSchedules(selectedDate))
  }
})

document.addEventListener('DOMContentLoaded', initScheduleUI)
