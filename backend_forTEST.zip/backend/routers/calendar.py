from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from database import get_db
import scheduleCRUD as crud
import schemas.calendar as schemas
from utils.auth import verify_token



from datetime import datetime



router = APIRouter()

@router.get("/{user_id}/{date_int}", response_model=list[schemas.CalendarEventOut])
def read_events(user_id: int, date_int: int, db: Session = Depends(get_db)):
    """
    GET /calendar_events/{user_id}/{date_int}
    -> 해당 사용자의 YYYYMMDD 일정 리스트 반환
    """
    return crud.get_events_by_user_and_date(db, user_id, date_int)

@router.post("", response_model=schemas.CalendarEventOut)
def create_calendar_event(ev_in: schemas.CalendarEventCreate, db: Session = Depends(get_db)):
    """
    POST /calendar_events
    body: { user_id, date, start, end, title, content }
    """
    # start ≤ end 검증
    if ev_in.end < ev_in.start:
        raise HTTPException(400, "end 시간은 start 시간보다 작을 수 없습니다.")
    return crud.create_event(db, ev_in)

@router.put("/{ev_id}", response_model=schemas.CalendarEventOut)
def update_calendar_event(ev_id: int, ev_up: schemas.CalendarEventUpdate, db: Session = Depends(get_db)):
    """
    PUT /calendar_events/{ev_id}
    body: 수정할 필드들 (date, start, end, title, content)
    """
    ev = crud.update_event(db, ev_id, ev_up)
    if not ev:
        raise HTTPException(404, "Event not found")
    return ev

@router.delete("/{ev_id}")
def delete_calendar_event(ev_id: int, db: Session = Depends(get_db)):
    """
    DELETE /calendar_events/{ev_id}
    """
    ev = crud.delete_event(db, ev_id)
    if not ev:
        raise HTTPException(404, "Event not found")
    return {"message": "Deleted"}