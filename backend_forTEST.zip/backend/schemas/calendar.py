from pydantic import BaseModel
from typing import Optional

class CalendarEventBase(BaseModel):
    date: int           # YYYYMMDD
    start: int          # 0~23
    end: int            # 1~24 (항상 start ≤ end)
    title: str
    content: Optional[str] = None

class CalendarEventCreate(CalendarEventBase):
    user_id: int        # 프론트에서 넘겨 주거나, 실제론 토큰에서 추출

class CalendarEventUpdate(BaseModel):
    date: Optional[int] = None
    start: Optional[int] = None
    end: Optional[int] = None
    title: Optional[str] = None
    content: Optional[str] = None

class CalendarEventOut(CalendarEventBase):
    id: int
    user_id: int

    class Config:
        from_attributes = True

