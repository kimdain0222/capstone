"""
CalendarEvent 테이블에 대한 SQLAlchemy 모델을 정의합니다.
"""
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship
from database import Base

class CalendarEvent(Base):
    __tablename__ = "calendar_events"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"))
    date = Column(Integer, nullable=False, index = True)  # YYYYMMDD
    start = Column(Integer, nullable=False, index = True)
    end =  Column(Integer, nullable=False)
    title = Column(String(50), nullable=False)
    content = Column(String(500), nullable=True)
    
    user = relationship("User", back_populates="events")
