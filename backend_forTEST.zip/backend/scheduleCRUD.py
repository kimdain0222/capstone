from sqlalchemy.orm import Session
from models.calendar import CalendarEvent
from schemas.calendar import CalendarEventCreate, CalendarEventUpdate

def get_events_by_user_and_date(db: Session, user_id: int, date: int):
    return (
        db.query(CalendarEvent)
          .filter(
            CalendarEvent.user_id == user_id,
            CalendarEvent.date    == date
          )
          .order_by(CalendarEvent.start)
          .all()
    )

def create_event(db: Session, ev: CalendarEventCreate):
    db_ev = CalendarEvent(**ev.dict())
    db.add(db_ev)
    db.commit()
    db.refresh(db_ev)
    return db_ev

def update_event(db: Session, ev_id: int, data: CalendarEventUpdate):
    db_ev = db.query(CalendarEvent).get(ev_id)
    if not db_ev:
        return None
    update_data = data.dict(exclude_unset=True)
    for key, val in update_data.items():
        setattr(db_ev, key, val)
    db.commit()
    db.refresh(db_ev)
    return db_ev

def delete_event(db: Session, ev_id: int):
    db_ev = db.query(CalendarEvent).get(ev_id)
    if not db_ev:
        return None
    db.delete(db_ev)
    db.commit()
    return db_ev